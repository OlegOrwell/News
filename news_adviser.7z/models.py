import numpy as np
from itertools import combinations
import torch
from transformers import AutoModelForSequenceClassification, BertTokenizer
from collections import Counter
import json

import tensorflow as tf
from tensorflow.python import keras
from tensorflow.python.keras.layers import Input, Dense, Dropout, LSTM, Flatten, RepeatVector, Conv1D, MaxPool1D, MaxPooling1D
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.optimizer_v2.adam import Adam
from tensorflow.keras.layers.experimental import preprocessing
tf.config.list_physical_devices('GPU')


''' Блок скоринга трансфорером '''
model_name = 'cointegrated/rubert-base-cased-dp-paraphrase-detection'
model = AutoModelForSequenceClassification.from_pretrained(model_name)
tokenizer = BertTokenizer.from_pretrained(model_name)

# def paraphrase():
#     model_name = 'cointegrated/rubert-base-cased-dp-paraphrase-detection'
#     model = AutoModelForSequenceClassification.from_pretrained(model_name)
#     tokenizer = BertTokenizer.from_pretrained(model_name)


def combinating_and_scoring(text):
    scores = []
    combos = combinations(list(range(len(text))), 2)
    for index, combo in enumerate(combos):
        score = compare_texts(text[combo[0]], text[combo[1]], combo)
        scores.append(score)
    return scores


def compare_texts(text1, text2, combo):
    batch = tokenizer(text1[0], text2[0], return_tensors='pt', truncation=True, max_length=512).to(model.device)
    with torch.inference_mode():
        proba = torch.softmax(model(**batch).logits, -1).cpu().numpy()
    return ((combo[0], combo[1]), [proba[0][1]], text1, "      MIDDLE    ", text2,
            "     END   ")  # p(non-paraphrase), p(paraphrase)


def result(text):

    # Код для отладки и эвалюации
    # scores_mirrored = []
    # scores_mirrored = text
    # temp = []
    # for i in scores_mirrored:
    #     couple = list(i[0])
    #     couple[1], couple[0] = couple[0], couple[1]
    #     temp.append(((couple[0], couple[1]), i[1], i[5], i[6], i[4], i[2], i[3], i[7]))
    # scores_mirrored = temp.copy()
    # text = scores_mirrored + text.copy()

    scored_list = sorted(text, key=lambda x: (x[0][0], -x[1][0]))
    shall_not_pass = []
    shall_pass = []
    for item in scored_list:
        if item[1][0] > 0.7 and item[0][1] not in shall_not_pass and item[0][1] != item[0][0]:
            shall_not_pass.append(item[0][1])
            shall_pass.append(item[0][0])

    par_dict = Counter(shall_pass)
    to_show_dict = {}
    for k, v in par_dict.items():
        if k in shall_pass:
            to_show_dict[k] = v
    to_show_dict = sorted(to_show_dict.items(), key=lambda x: -x[1])
    shall_pass = list(set(shall_pass))

    #    top_scored = scored_list[::len(data_set) - 1]
#    top_scored = scored_list[::len(text) - 1]
#    count = 0

    # for top in top_scored:
    #     if top[6] != 0 and top[3] != 0:
    #         #            print(top)
    #         count += 1
    #         print(top)
    # #         count += 1
    with open("./data/shall_pass.json", "w") as file:
        json.dump(shall_pass, file)
    #    csvwriter.writerow(fields)
    #    csvwriter.writerows(shall_pass)

    return shall_pass


''' Блок Bag-of-Words'''


def get_grams(text):
    unigrams = True
    bigrams = True
    skipgrams = True
    ngrams = []
    app_grams = []
    counter = {}
    for index, sentence in enumerate(text):
        row_engrams, joined = get_ingrams_from_sentence(sentence, unigrams, bigrams, skipgrams)
        ngrams.extend(row_engrams)
        app_grams.append(row_engrams)
    # for ngram in ngrams:
    #     #        print(ngram)
    #     counter[ngram] = [0] * len(text)
    # for index, units in enumerate(app_grams):
    #     for unit in units:
    #         if unit in counter.keys():
    #             counter[unit][index] = counter[unit][index] + 1
    return ngrams, counter, app_grams, len(text)


def get_ingrams_from_sentence(text, unigrams, bigrams, skipgrams):
    line_list = []
    join_list = []
    text = text[0].split()
    for index, word in enumerate(text):
        if word != '':
            if unigrams:
                #   Adding uni-gram
                line_list.append(word)
                join_list.append(word)

            if bigrams:
                if index < len(text) - 1:
                    line_list.append((word, text[index + 1]))
                    join_list.append(word + text[index + 1])

            #   Adding skip-gram
                if word != text[index - 1] and index > 0:
                    line_list.append((word, text[index - 1]))
                    join_list.append(word + text[index - 1])

            if skipgrams:
                if word != text[index - 2] and index > 1:
                    line_list.append((word, text[index - 2]))
                    join_list.append(word + text[index - 2])
                if index < len(text) - 2:
                    line_list.append((word, text[index + 2]))
                    join_list.append(word + text[index + 2])
    return line_list, join_list


def evaluate(tokens, lists):
    """Set reduce_to_one True if you don't any word to
            be counted more when one time per sentence"""

    combos = [x for x in combinations(list(range(len(lists))), 2)]
    reduce_to_one = False
    result_dict = {}
    # uni_decrement = 0.7
    # length = len(lists)
    result_for_left = []
    result_for_right = []

    for combo in combos:
        left, right = combo
        vocabulary = tokens[left] + tokens[right]
        left_list = [0] * len(vocabulary)
        right_list = [0] * len(vocabulary)
        line_left = lists[left]
        line_right = lists[right]
        for index, word in enumerate(line_left):
            for ind, vocab_word in enumerate(vocabulary):
                counter = 0
                if word == vocab_word:
                    counter += 1
                #                 if word == vocab_word and isinstance(word, str) == True:
                #                     counter += 1 * uni_decrement
                #                 else:
                #                     counter += 1

                left_list[ind] += counter
        result_for_left.append(left_list)
        # print(left_list)

        for index, word in enumerate(line_right):
            for ind, vocab_word in enumerate(vocabulary):
                counter = 0
                #    print(vocab_word)
                if word == vocab_word:
                    counter += 1
                #                 if word == vocab_word and isinstance(word, str) == True:
                #                     counter += 1 * uni_decrement
                #                 else:
                #                     counter += 1
                right_list[ind] += counter
        result_for_right.append(right_list)
        # print(right_list)

        #  result.append(np.dot(np.array(left_list)), np.transpose(np.array(right_list)))
        left_array = np.array(left_list)
        right_array = np.array(right_list)
        if reduce_to_one:
            for left_value, right_value in zip(left_array, right_array):
                if left_value > 0:
                    left_value = 1
                if right_value > 0:
                    right_value = 1

                    # result_dict[combo] = np.dot(np.array(left_list),
                    # np.transpose(np.array(right_list)))/len(vocabulary)
        result_dict[combo] = np.matmul(left_array, np.transpose(right_array)) / len(vocabulary)
    results = sorted(result_dict.items(), key=lambda x: x[1])
    results = results[::-1]
    return results


''' Блок самостоятельного обучения эмбеддингов слов и их скоринг'''


def to_train(sentences, not_cleared):
    """Set window_size = 1 to get one word nearest to target, set window_size = 2 to get 2 nearby words"""
    window_size = 2
    data = []
    words = []
    x_set = []
    y_set = []
    one_hot_dict = {}
    unique_dict = {}
    x_hot = []
    y_hot = []
    for sentence in sentences:
        sent_splitted = sentence[0].lower().split(' ')
        for index, word in enumerate(sent_splitted):
            for character in word:
                if character == " ":
                    character = ""
            if index != len(sent_splitted) - 1:
                data.append((word.strip(), sent_splitted[index + 1]))
                words.append(word.strip())
                x_set.append(word.strip())
                y_set.append(sent_splitted[index + 1])
            if index != 0:
                data.append((word.strip(), sent_splitted[index - 1]))
                words.append(word.strip())
                x_set.append(word.strip())
                y_set.append(sent_splitted[index - 1])
            if window_size > 1:
                if index != len(sent_splitted) - 1 and index != len(sent_splitted) - 2:
                    data.append((word.strip(), sent_splitted[index + 2]))
                    words.append(word.strip())
                    x_set.append(word.strip())
                    y_set.append(sent_splitted[index + 2])
                if index != 0 and index != 1:
                    data.append((word.strip(), sent_splitted[index - 1]))
                    words.append(word.strip())
                    x_set.append(word.strip())
                    y_set.append(sent_splitted[index - 1])

    unique_words = list(set(words))
    for index, word in enumerate(unique_words):
        if word != ' ' and word != '':
            #             unique_dict[word] = index - 1
            #             one_hot_list = [0] * (len(unique_words)-1)
            #             one_hot_list[index - 1 ] = 1
            #             one_hot_dict[word] = one_hot_list
            unique_dict[word] = index
            one_hot_list = [0] * (len(unique_words))
            one_hot_list[index] = 1
            one_hot_dict[word] = one_hot_list
    for index, (x, y) in enumerate(zip(x_set, y_set)):
        x_hot.append(one_hot_dict.get(x, [int(0)] * (len(unique_words) - 1)))
        y_hot.append(one_hot_dict.get(y, [int(0)] * (len(unique_words) - 1)))

    x = np.array(x_hot).reshape(-1, 1, len(unique_words))
    y = np.array(y_hot).reshape(-1, 1, len(unique_words))

    model = Sequential()
    model.add(Dense(units=32, activation="linear"))
    model.add(Dense(units=len(unique_words), activation="softmax"))
    train = tf.data.Dataset.from_tensor_slices((x, y))
    optimizer = Adam(learning_rate=0.001)
    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
    model.fit(train, epochs=100)
    got_weights = model.get_weights()[0]
    unique_vector_dict = unique_dict.copy()
    for (k, v), i in zip(unique_vector_dict.items(), got_weights):
        unique_vector_dict[k] = i
    vector_sentences = vectorize_sentences(sentences, unique_vector_dict)
    scores, titles = embedding_combinating_and_scoring(vector_sentences, sentences, not_cleared)

    titles.sort(reverse=True)
    scored_list = sorted(titles, key=lambda x: (x[1][1], -x[0]))
    scores_dict = {}
    for item in scored_list:
        scores_dict[item[1][1]] = scores_dict.get(item[1][1], []) + [item[2][1]]
    # titles[::-1]
    with open("./data/relations.json", "w") as file:
        json.dump(scores_dict, file)
    return scores_dict

 #   return x, y, unique_dict, unique_words, one_hot_dict, x_set, y_set


def vectorize_sentences(sentences, vectors_in_dict):
    new_sentences = []
    for sentence in sentences:
        new_line = []
        for index, word in enumerate(sentence[0].split(" ")):
            if len(word) > 1 and word != ' ':
                new_line.append(vectors_in_dict[word.strip()])
        new_sentences.append(new_line)
    return new_sentences


def embedding_combinating_and_scoring(vector_sentences, sentences, text):
    scores = []
    combos = combinations(list(range(len(vector_sentences))), 2)
    titles = []

    for index, combo in enumerate(combos):
        left_stacked = stack_vectors(vector_sentences[combo[0]])
        right_stacked = stack_vectors(vector_sentences[combo[1]])
        product = np.dot(left_stacked, np.transpose(right_stacked))
        score = np.sum(product)
        scores.append((score, combo[0], combo[1]))
        scores.append((score, combo[1], combo[0]))
        titles.append((score, text[combo[0]], text[combo[1]]))
        titles.append((score, text[combo[1]], text[combo[0]]))
    return scores, titles


def stack_vectors(sentence_for_stacking):
    return np.stack(sentence_for_stacking, axis=0)

