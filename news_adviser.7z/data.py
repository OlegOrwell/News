import pandas as pd
from datetime import datetime, timedelta
from text_prep import ru_clear



def get_data():
    compiled_df = pd.read_csv('data/compiled.csv', index_col=[0])
    compiled_df.sort_values(by="time", inplace=True)

    # Выбрать по количеству последних записей в таблице.
    global example
    example = compiled_df.tail(150)
    # Выбрать интервал в часах от времени публикации самой свежей новости в сете.
    # interval_time = datetime.strptime(compiled_df['time'].max(), '%Y-%m-%d %H:%M:%S') - timedelta(hours=4)
    # example = compiled_df.loc[compiled_df["time"] >= interval_time.strftime('%Y-%m-%d %H:%M:%S')]['time']

    example.to_csv('./data/selection.csv')
    example = list(example.title)


    numerated_example = [(title, value) for value, title in enumerate(example) if len(title) > 1]
    return numerated_example

def clear_text(text):
    return ru_clear(text, is_stopword=True, is_stemm=False)


# from models import combinating_and_scoring, result
# from models import get_grams, evaluate
# from models import to_train
#
# print(result(combinating_and_scoring(clear_text(get_data()))))
# print(to_train(clear_text(get_data()), get_data()))
