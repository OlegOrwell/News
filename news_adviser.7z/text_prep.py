import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from string import punctuation
from pymystem3 import Mystem


def ru_clear(args, is_stopword=True, is_stemm=False, is_lemma=False):
    stemmer = SnowballStemmer("russian")
    mystem = Mystem()

    symbols = "~!@#$?><%^&*)(_+=-*|/"
    punct = ",.'`;:"
    stoplist = ['\xa0130', '\xa065', '\xa0', '\n', '"', '«', '»']
    new_list = []
    temp = str()

    russian_stopwords = stopwords.words("russian")
    for arg in args:
        for symbol in symbols:
            temp = arg[0].replace(symbol, "")
        for pun in punct:
            temp = arg[0].replace(pun, "")
        for stop in stoplist:
            temp = arg[0].replace(stop, " ")
        if is_lemma:
            tokens = mystem.lemmatize(temp.lower())
        else:
            tokens = nltk.word_tokenize(temp.lower())

        if is_stopword:
            tokens = [token.strip() for token in tokens if
                      token not in russian_stopwords and token != ' ' and token not in punctuation]
        else:
            tokens = [token.strip() for token in tokens if token != ' ' and token not in punctuation]

        line = str()
        for token in tokens:
            if is_stemm:
                token = stemmer.stem(token)
            line += token.strip() + " "
        new_list.append((line[:-1], arg[1]))

    return new_list
